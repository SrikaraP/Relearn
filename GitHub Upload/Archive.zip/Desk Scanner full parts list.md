# Desk Scanner Full Parts List

Generated from the final PCB file. `Qty` is grouped by identical value, footprint, and install status.

| Qty | References | Common name | PCB value | KiCad footprint | Install / buy status | Separate item to plug in |
|---:|---|---|---|---|---|---|
| 1 | BT1 | Wired RTC coin-cell connector | Wired RTC cell input | :JST_SH_BM02B-SRSS-TB_1x02-1MP_P1.00mm_Vertical | PCB connector; wired RTC cell is separate | Wired RTC/coin-cell battery |
| 1 | BZ1 | Active magnetic buzzer | 5V active buzzer | Buzzer_Beeper:PUIAudio_SMT_0825_S_4_R | Buy and solder/assemble onto PCB |  |
| 1 | C1 | SMD capacitor | 10uF USB VBUS | Capacitor_SMD:C_1206_3216Metric | Buy and solder/assemble onto PCB |  |
| 1 | C10 | SMD capacitor | 100nF BAT filter | Capacitor_SMD:C_0603_1608Metric | Buy and solder/assemble onto PCB |  |
| 1 | C11 | SMD capacitor | 100nF 5V filter | Capacitor_SMD:C_0603_1608Metric | Buy and solder/assemble onto PCB |  |
| 1 | C2 | SMD capacitor | 100uF bulk | Capacitor_SMD:CP_Elec_6.3x5.8 | Buy and solder/assemble onto PCB |  |
| 1 | C3 | SMD capacitor | 10uF | Capacitor_SMD:C_1206_3216Metric | Buy and solder/assemble onto PCB |  |
| 2 | C4, C5 | SMD capacitor | 10uF 50V X7R | Capacitor_SMD:C_1206_3216Metric | Buy and solder/assemble onto PCB |  |
| 2 | C6, C7 | SMD capacitor | 1nF soft-start | Capacitor_SMD:C_0603_1608Metric | Buy and solder/assemble onto PCB |  |
| 2 | C8, C9 | SMD capacitor | 100nF debounce | Capacitor_SMD:C_0603_1608Metric | Buy and solder/assemble onto PCB |  |
| 1 | D2 | TVS protection diode | SMBJ16A TVS | Diode_SMD:D_SMB | Buy and solder/assemble onto PCB |  |
| 2 | D3, D4 | Schottky diode | SS34 Schottky | Diode_SMD:D_SMA | Buy and solder/assemble onto PCB |  |
| 1 | D5 | Indicator LED | ACT LED green | LED_SMD:LED_0603_1608Metric | Buy and solder/assemble onto PCB |  |
| 1 | D6 | Indicator LED | Power LED | LED_SMD:LED_0603_1608Metric | Buy and solder/assemble onto PCB |  |
| 1 | D7 | Indicator LED | CM5 PWR status LED | LED_SMD:LED_0603_1608Metric | Buy and solder/assemble onto PCB |  |
| 1 | F1 | Blade/holder fuse footprint | 7.5A battery fuse | Fuse:Fuse_2920_7451Metric | Buy and solder/assemble onto PCB |  |
| 4 | H1, H2, H3, H4 | M2.5 mounting hole | M2.5 | :MountingHole_2.7mm_M2.5_DIN965 | Fabricated in PCB; buy M2.5 screws/standoffs separately if needed | M2.5 screw/standoff |
| 1 | J1 | USB-C receptacle | USB-C USB2 Data + 5V Input | Connector_USB:USB_C_Receptacle_GCT_USB4105-xx-A_16P_TopMnt_Horizontal | Soldered to PCB; USB-C cable/host computer is separate | USB-C cable to computer/power |
| 1 | J10 | LED bar output connector | LED bar 2 output | Connector_JST:JST_VH_B2P-VH_1x02_P3.96mm_Vertical | PCB connector; LED bar/light assembly is separate | External LED bar 2 |
| 1 | J11 | Optional fan connector | 5V PWM fan | Connector_JST:JST_SH_BM04B-SRSS-TB_1x04-1MP_P1.00mm_Vertical | Optional/DNP unless using a power-only 5V fan | Optional 5V fan |
| 1 | J12 | UART debug header | UART debug 3-pin | Connector_JST:JST_SH_BM03B-SRSS-TB_1x03-1MP_P1.00mm_Vertical | Optional debug header; plug USB-UART adapter separately | Optional USB-UART adapter/cable |
| 1 | J2 | USB-A receptacle | USB-A Host USB3 | Connector_USB:USB3_A_Receptacle_Wuerth_692122030100 | Soldered to PCB; USB device/cable is separate | USB-A plug/cable/device |
| 1 | J3 | 22-pin camera FFC connector | Camera FFC - Raspberry Pi Camera Module 3 AF | CM5IO:Hirose_FH12-22S-0.5SH_1x22-1MP_P0.50mm_Horizontal | PCB connector; buy camera module separately and plug in by FFC | Raspberry Pi Camera Module 3 Autofocus and 22-pin FFC |
| 1 | J4 | 22-pin display DSI FFC connector | Display FFC - Raspberry Pi Touch Display 2 | CM5IO:Hirose_FH12-22S-0.5SH_1x22-1MP_P0.50mm_Horizontal | PCB connector; buy Raspberry Pi Touch Display 2 separately and plug in by FFC | Raspberry Pi Touch Display 2, 5-inch, and correct DSI FFC |
| 1 | J5 | Display power connector/header | Display 5V Power | Connector_JST:JST_VH_B2P-VH_1x02_P3.96mm_Vertical | PCB connector/header; display power cable/display are separate | Display 5V power lead |
| 1 | J6 | XT30 battery connector | 3S protected Li-ion pack input XT30 | Connector_AMASS:AMASS_XT30PW-M_1x02_P2.50mm_Horizontal | PCB connector; 3S protected Li-ion pack is separate | 3S protected Li-ion battery pack with XT30 mating connector |
| 1 | J7 | Buck-regulator module header | 5V 6A buck regulator module | Connector_JST:JST_VH_B4P-VH_1x04_P3.96mm_Vertical | PCB header; 5V 6A buck regulator module is separate | 5V 6A buck regulator module |
| 1 | J8 | 5V source-selector/header | High-current 5V source selector | Connector_JST:JST_VH_B3P-VH_1x03_P3.96mm_Vertical | Buy and solder/assemble onto PCB | Jumper/shunt or wired source-select link as implemented |
| 1 | J9 | LED bar output connector | LED bar 1 output | Connector_JST:JST_VH_B2P-VH_1x02_P3.96mm_Vertical | PCB connector; LED bar/light assembly is separate | External LED bar 1 |
| 1 | JP1 | Solder jumper | USB OTG ID strap - leave open for device mode | Jumper:SolderJumper-2_P1.3mm_Open_TrianglePad1.0x1.5mm | PCB solder jumper; no separate part unless fitting a 0R link |  |
| 2 | L1, L2 | Shielded power inductor | 47uH >=2A shielded | CM5IO:L_Bourns_SRP5030CC | Buy and solder/assemble onto PCB |  |
| 1 | Q1 | Small-signal N-MOSFET | 2N7002 buzzer low-side | Package_TO_SOT_SMD:SOT-23 | Buy and solder/assemble onto PCB |  |
| 1 | R1 | SMD resistor | 10k USB ILIM set | Resistor_SMD:R_0603_1608Metric | Buy and solder/assemble onto PCB |  |
| 2 | R10, R11 | SMD resistor | 10k | Resistor_SMD:R_0603_1608Metric | Buy and solder/assemble onto PCB |  |
| 1 | R12 | SMD resistor | 100R gate | Resistor_SMD:R_0603_1608Metric | Buy and solder/assemble onto PCB |  |
| 1 | R13 | SMD resistor | 100k gate pulldown | Resistor_SMD:R_0603_1608Metric | Buy and solder/assemble onto PCB |  |
| 1 | R14 | SMD resistor | 1k ACT | Resistor_SMD:R_0603_1608Metric | Buy and solder/assemble onto PCB |  |
| 1 | R15 | SMD resistor | 1k PWR | Resistor_SMD:R_0603_1608Metric | Buy and solder/assemble onto PCB |  |
| 1 | R16 | SMD resistor | 10k tach pull-up | Resistor_SMD:R_0603_1608Metric | DNP option; fan tach was left unused |  |
| 1 | R17 | SMD resistor | 2.2k SDA pull-up | Resistor_SMD:R_0603_1608Metric | Buy and solder/assemble onto PCB |  |
| 1 | R18 | SMD resistor | 2.2k SCL pull-up | Resistor_SMD:R_0603_1608Metric | Buy and solder/assemble onto PCB |  |
| 1 | R19 | SMD resistor | 100k BAT top | Resistor_SMD:R_0603_1608Metric | Buy and solder/assemble onto PCB |  |
| 1 | R2 | SMD resistor | 10k PMIC enable pull-up | Resistor_SMD:R_0603_1608Metric | Buy and solder/assemble onto PCB |  |
| 1 | R20 | SMD resistor | 22k BAT bottom | Resistor_SMD:R_0603_1608Metric | Buy and solder/assemble onto PCB |  |
| 1 | R21 | SMD resistor | 47k 5V top | Resistor_SMD:R_0603_1608Metric | Buy and solder/assemble onto PCB |  |
| 1 | R22 | SMD resistor | 47k 5V bottom | Resistor_SMD:R_0603_1608Metric | Buy and solder/assemble onto PCB |  |
| 1 | R23 | SMD resistor | 1k CM5 PWR | Resistor_SMD:R_0603_1608Metric | Buy and solder/assemble onto PCB |  |
| 1 | R3 | SMD resistor | 10k WLAN enable pull-up | Resistor_SMD:R_0603_1608Metric | Buy and solder/assemble onto PCB |  |
| 1 | R4 | SMD resistor | 10k Bluetooth enable pull-up | Resistor_SMD:R_0603_1608Metric | Buy and solder/assemble onto PCB |  |
| 1 | R5 | SMD resistor | 10k boot pull-up | Resistor_SMD:R_0603_1608Metric | Buy and solder/assemble onto PCB |  |
| 1 | R6 | SMD resistor | 0R LED_SUPPLY from +5V_SYS | Resistor_SMD:R_1206_3216Metric | Buy and solder/assemble onto PCB |  |
| 1 | R7 | SMD resistor | 0R DNP LED_SUPPLY from BAT_FUSED | Resistor_SMD:R_1206_3216Metric | DNP option; do not fit for normal +5V_SYS LED supply |  |
| 2 | R8, R9 | SMD resistor | 0.15R 1% 0.5W LED sense | Resistor_SMD:R_2512_6332Metric | Buy and solder/assemble onto PCB |  |
| 1 | SW1 | Tactile pushbutton switch | Scan/Capture button | Button_Switch_SMD:SW_SPST_PTS645Sx43SMTR92 | Buy and solder/assemble onto PCB |  |
| 1 | SW2 | Tactile pushbutton switch | Lighting level button | Button_Switch_SMD:SW_SPST_PTS645Sx43SMTR92 | Buy and solder/assemble onto PCB |  |
| 1 | SW3 | Tactile pushbutton switch | nRPIBOOT recovery | Button_Switch_SMD:SW_SPST_PTS645Sx43SMTR92 | Buy and solder/assemble onto PCB |  |
| 1 | SW4 | Tactile pushbutton switch | CM5 power button | Button_Switch_SMD:SW_SPST_PTS645Sx43SMTR92 | Buy and solder/assemble onto PCB |  |
| 1 | U1 | Raspberry Pi Compute Module 5 module | Raspberry Pi CM5 Wireless 8GB/64GB eMMC | CM5IO:Raspberry-Pi-5-Compute-Module | Buy separately and mount/plug onto the PCB | Raspberry Pi CM5 Wireless 8GB/64GB eMMC module |
| 1 | U2 | USB power-distribution/load switch IC | AP2553W6 USB Host Power Switch | Package_TO_SOT_SMD:SOT-23-6 | Buy and solder/assemble onto PCB |  |
| 1 | U3 | LED constant-current buck driver IC | AL8860MP LED driver 1 | Package_SO:MSOP-8-1EP_3x3mm_P0.65mm_EP1.5x1.8mm | Buy and solder/assemble onto PCB |  |
| 1 | U4 | LED constant-current buck driver IC | AL8860MP LED driver 2 | Package_SO:MSOP-8-1EP_3x3mm_P0.65mm_EP1.5x1.8mm | Buy and solder/assemble onto PCB |  |
| 1 | U5 | ADS1115 I2C ADC IC | ADS1115 battery/system monitor | Package_SO:TSSOP-10_3x3mm_P0.5mm | Buy and solder/assemble onto PCB |  |
